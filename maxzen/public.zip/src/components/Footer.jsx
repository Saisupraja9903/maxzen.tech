import React from "react";
import {
  FaMapMarkerAlt,
  FaEnvelope,
  FaPhoneAlt,
  FaFacebookF,
  FaInstagram,
  FaTwitter,
  FaYoutube,
  FaWhatsapp,
} from "react-icons/fa";
import logo2 from "../assests/logo2.png"; // replace with your actual logo
import logoo1 from "../assests/logoo1.png"; // replace with your background image

const Footer = () => {
  return (
    <footer
      className="relative bg-cover bg-center text-white w-full h-full"
      style={{ backgroundImage: `url(${logoo1})` }}
    >
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/50"></div>

      {/* Content */}
      <div className="relative max-w-8xl mx-auto px-6 py-16 text-center md:text-left">
        {/* Top Section */}
        <div className="flex flex-col items-center md:items-start space-y-6">
          {/* Logo + Tagline */}
          <div className="flex flex-col items-center md:items-start">
            <img src={logo2} alt="Logo" className="w-40 mb-3" />
            <p className="text-lg">Innovate. Transform. Lead.</p>
          </div>

          {/* Email Subscribe */}
          <div className="mt-8 w-full flex flex-col items-center">
            <h2 className="text-3xl font-semibold mb-6">
              Get The Best Stories Into Your Inbox
            </h2>
            <div className="flex w-full max-w-3xl bg-white/20 backdrop-blur-md rounded-lg overflow-hidden">
              <input
                type="email"
                placeholder="Email"
                className="flex-1 px-4 py-3 bg-transparent outline-none text-white placeholder-gray-200"
              />
              <button className="px-6 py-3 bg-white text-black font-semibold hover:bg-gray-200 transition-all">
                SUBMIT
              </button>
            </div>
            <button className="mt-6 px-6 py-2 border border-white rounded-full hover:bg-white hover:text-black transition-all">
              View All Blogs
            </button>
          </div>
        </div>

        {/* Bottom Info */}
        <div className="mt-16 grid md:grid-cols-3 gap-10 text-center md:text-left">
          {/* Office Address */}
          <div>
            <h3 className="text-2xl font-bold mb-3">Office Address</h3>
            <p className="flex items-start justify-center md:justify-start gap-2">
              <FaMapMarkerAlt className="text-red-500 mt-1" />
              4th, Manjeera Trinity Corporate,<br /> KPHB, Hyderabad
            </p>
          </div>

          {/* Contact Us */}
          <div>
            <h3 className="text-2xl font-bold mb-3">Contact Us</h3>
            <p className="flex items-center justify-center md:justify-start gap-2">
              <FaEnvelope className="text-red-500" /> info@maxzen.tech
            </p>
            <p className="flex items-center justify-center md:justify-start gap-2 mt-2">
              <FaPhoneAlt className="text-red-500" /> +91 90599 91807
            </p>
          </div>

          {/* We Are Social */}
          <div>
            <h3 className="text-2xl font-bold mb-3">We Are Social</h3>
            <div className="flex justify-center md:justify-start gap-4">
              <a href="#" className="p-3 text-red-500 rounded-full hover:bg-white hover:text-black transition-all">
                <FaFacebookF />
              </a>
              {/* <a href="#" className="p-3 bg-white/20 rounded-full hover:bg-white hover:text-black transition-all">
                <FaInstagram /> */}
                 <a href="#" className="p-3 text-red-500 rounded-full hover:bg-white hover:text-black transition-all">
                <FaInstagram />
              </a>
              <a href="#" className="p-3 text-red-500 rounded-full hover:bg-white hover:text-black transition-all">
                <FaTwitter />
              </a>
              <a href="#" className="p-3 text-red-500 rounded-full hover:bg-white hover:text-black transition-all">
                <FaYoutube />
              </a>
            </div>
          </div>
        </div>

        {/* WhatsApp Floating Icon */}
        <a
          href="https://wa.me/919059991807"
          target="_blank"
          rel="noreferrer"
          className="fixed bottom-6 left-6 bg-green-500 text-white p-4 rounded-full text-2xl shadow-lg hover:scale-110 transition-transform"
        >
          <FaWhatsapp />
        </a>

        {/* Footer Bottom */}
        <div className="mt-20 border-t border-white/30 pt-6 flex flex-col md:flex-row justify-between items-center text-sm text-gray-200">
          <div className="flex gap-6 mb-4 md:mb-0">
            <a href="#" className="hover:text-white">Home</a>
            <a href="#" className="hover:text-white">Contact</a>
            <a href="#" className="hover:text-white">Terms & Condition</a>
            <a href="#" className="hover:text-white">Privacy Policy</a>
          </div>
          <p>© 2025–2026 maxzen.tech. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
