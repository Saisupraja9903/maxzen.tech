import React, { useEffect, useState } from "react";
import { FaPhoneAlt, FaMapMarkerAlt, FaEnvelope } from "react-icons/fa";

const ContactSection = () => {
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    // Trigger animation once after refresh
    setAnimate(true);
    const timer = setTimeout(() => setAnimate(false), 2500); // stop after 2.5s
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="text-center py-16 px-6 bg-white">
      {/* Top Text */}
      <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-2">
        Clicks. Conversions. Confidence That’s{" "}
        <span
          className={`relative text-blue-600 transition-all duration-700 ${
            animate ? "circle-animate" : ""
          }`}
        >
          Maxzen.Tech
          <span className="absolute inset-0 border-2 border-blue-600 rounded-full opacity-0 animate-none"></span>
        </span>
      </h2>

      <p className="text-xl text-pink-600 font-semibold mb-10">
        Let’s Grow Your Brand Together — Contact the Leading Digital Marketing
        Agency in Hyderabad Today!
      </p>

      {/* Contact Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-16">
        {/* Call Us Card */}
        <div className="border border-gray-300 rounded-2xl p-8 flex flex-col items-center shadow-sm hover:shadow-lg transition-shadow duration-300">
          <FaPhoneAlt className="text-gray-600 text-5xl mb-4" />
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            Call us at
          </h3>
          <p className="text-gray-600 text-lg">+91 90599 91807</p>
        </div>

        {/* Our Office Card */}
        <div className="border border-gray-300 rounded-2xl p-8 flex flex-col items-center shadow-sm hover:shadow-lg transition-shadow duration-300">
          <FaMapMarkerAlt className="text-gray-600 text-5xl mb-4" />
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            Our Office
          </h3>
          <p className="text-gray-600 text-lg leading-relaxed">
            4th floor, Manjeera Trinity Corporate, <br /> KPHB, Hyderabad
          </p>
        </div>

        {/* E-mail Us Card */}
        <div className="border border-gray-300 rounded-2xl p-8 flex flex-col items-center shadow-sm hover:shadow-lg transition-shadow duration-300">
          <FaEnvelope className="text-gray-600 text-5xl mb-4" />
          <h3 className="text-xl font-semibold text-gray-800 mb-2">
            E-mail us at
          </h3>
          <p className="text-gray-600 text-lg">info@maxzen.tech</p>
        </div>
      </div>

      {/* Global Locations Section */}
      <div className="max-w-4xl mx-auto">
        <p className="text-sm text-red-600 font-semibold tracking-widest mb-2">
          BRANCHES
        </p>
        <h3 className="text-3xl font-extrabold text-gray-900 mb-4">
          Our Global Locations
        </h3>
        <p className="text-gray-700 text-lg leading-relaxed">
          At{" "}
          <span className="text-blue-600 font-semibold">Maxzen.tech</span>, we’re
          more than just a digital marketing agency in Hyderabad — we serve
          clients across the globe with the same passion and performance.
        </p>
        <p className="text-gray-700 text-lg mt-4 leading-relaxed">
          Our expert team delivers{" "}
          <span className="font-semibold text-blue-600">SEO</span>, Google Ads,{" "}
          <span className="font-semibold text-blue-600">
            social media marketing
          </span>
          , and website design services to help businesses grow online — no
          matter where they are.
        </p>
      </div>
    </section>
  );
};

export default ContactSection;
