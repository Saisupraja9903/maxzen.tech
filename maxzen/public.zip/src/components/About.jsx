import React from "react";

const About = () => {
  return (
    <section className="bg-white text-gray-800 py-16 px-6 md:px-20">
      <div className="max-w-6xl mx-auto">
        {/* Heading */}
        <h2 className="text-4xl md:text-5xl font-bold mb-6 text-black text-left">
          About <span className="text-black">Maxzen.Tech</span>
        </h2>

        {/* Paragraph 1 */}
        <p className="text-lg leading-relaxed mb-6 text-left">
          At{" "}
          <span className="text-orange-500 font-semibold">Maxzen.Tech</span>, we
          are a full-service digital marketing agency in Hyderabad, located at
          Manjeera Trinity Corporate, 4th Floor, Unit 408, Pin – 500072 JNTU
          Road. We specialize in providing innovative, affordable, and
          result-driven solutions for businesses of all sizes. Our mission is
          simple – to help brands grow digitally, generate organic leads, and
          scale their online presence with cutting-edge strategies.
        </p>

        {/* Paragraph 2 */}
        <p className="text-lg leading-relaxed mb-6 text-left">
          With a team of passionate professionals, we blend creativity,
          technology, and marketing expertise to deliver measurable results.
          From <span className="font-semibold text-gray-900">SEO</span> to Paid
          Ads,{" "}
          <span className="text-orange-500 font-semibold">Website Design</span>{" "}
          to{" "}
          <span className="text-orange-500 font-semibold">
            Cloud Development
          </span>
          , we cover everything your business needs to stay ahead in today’s
          competitive world.
        </p>

        {/* Small subheading */}
        <p className="uppercase tracking-wider text-sm font-semibold text-orange-600 mb-3 text-left">
          What We Do
        </p>

        {/* Second heading */}
        <h3 className="text-3xl md:text-4xl font-bold mb-4 text-black text-left">
          Redefine Business
        </h3>

        {/* Paragraph 3 */}
        <p className="text-lg leading-relaxed text-gray-700 text-left">
          We help businesses evolve with innovative solutions that drive
          efficiency and growth. Our approach blends cutting-edge technology
          with strategic insights to create lasting impact. We specialize in
          streamlining operations, enhancing digital presence, and implementing
          data-driven strategies to help businesses stay ahead in a competitive
          market. With a focus on innovation and adaptability, we empower
          organizations to achieve sustainable success.
        </p>
      </div>
    </section>
  );
};

export default About;
