// Header.jsx
import React, { useState } from "react";
import { FaInstagram, FaFacebookF, FaTwitter, FaBars, FaTimes } from "react-icons/fa";
import logo from "../assests/maxzen logo.webp"; // Replace with your logo path

const Header = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="bg-[#F2F5D1] sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">

        {/* Left Section - Logo */}
        <div className="flex items-center gap-4">
          <img
            src={logo}
            alt="Maxzen Logo"
            className="h-14 w-14 rounded-full object-cover"
          />
          <div className="flex flex-col justify-center leading-tight">
            <span className="text-black font-semibold text-3xl font-sans">
              Maxzen.Tech
            </span>
            <span className="text-black font-semibold text-3xl font-sans">
             
            </span>
          </div>
        </div>

        {/* Center Section - Navigation */}
        <nav className="hidden md:flex">
          <ul className="flex gap-10 text-black font-medium">
            <li className="hover:text-yellow-400 transition-colors">
              <a href="#">Home</a>
            </li>
            <li className="hover:text-yellow-400 transition-colors">
              <a href="#">About</a>
            </li>
            <li className="hover:text-yellow-400 transition-colors">
              <a href="#">Services</a>
            </li>
            <li className="hover:text-yellow-400 transition-colors">
              <a href="#">Blog</a>
            </li>
            <li className="hover:text-yellow-400 transition-colors">
              <a href="#">Contact</a>
            </li>
          </ul>
        </nav>

        {/* Right Section - Social Icons */}
        {/* <div className="hidden md:flex gap-4 text-xl">
          <a href="#" className="text-[#E4405F] hover:scale-110 transition-transform">
            <FaInstagram />
          </a>
          <a href="#" className="text-[#1877F2] hover:scale-110 transition-transform">
            <FaFacebookF />
          </a>
          <a href="#" className="text-[#1DA1F2] hover:scale-110 transition-transform">
            <FaTwitter />
          </a>
        </div> */}

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-black text-2xl"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <FaTimes /> : <FaBars />}
        </button>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-[#F2F5D1] px-6 pb-4">
          <ul className="flex flex-col gap-4 text-black font-medium">
            <li className="hover:text-yellow-400 transition-colors">
              <a href="#">Home</a>
            </li>
            <li className="hover:text-yellow-400 transition-colors">
              <a href="#">About</a>
            </li>
            <li className="hover:text-yellow-400 transition-colors">
              <a href="#">Courses</a>
            </li>
            <li className="hover:text-yellow-400 transition-colors">
              <a href="#">Blog</a>
            </li>
            <li className="hover:text-yellow-400 transition-colors">
              <a href="#">Contact</a>
            </li>
          </ul>

          {/* Mobile Social Icons */}
          <div className="flex gap-4 mt-4 text-xl">
            <a href="#" className="text-[#E4405F] hover:scale-110 transition-transform">
              <FaInstagram />
            </a>
            <a href="#" className="text-[#1877F2] hover:scale-110 transition-transform">
              <FaFacebookF />
            </a>
            <a href="#" className="text-[#1DA1F2] hover:scale-110 transition-transform">
              <FaTwitter />
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
