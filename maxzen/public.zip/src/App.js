import logo from './logo.svg';
import './App.css';
import Headers from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import About from './components/About.jsx';
import BusinessIntro from './components/BusinessIntro.jsx';
import BlogSection from './components/BlogSection.jsx';
import MarqueeText from './components/MarqueeText.jsx';
import Testimonials from './components/Testimonals.jsx';
import TeamSection from './components/TeamSection.jsx';
import OurProcess from './components/OurProcess.jsx';
import ProjectsSection from './components/ProjectsSection.jsx';
import GoalsSection from './components/GoalSection.jsx';
import ContactUs from './components/ContactUs.jsx'
import MapSection from './components/MapSection.jsx';
import CartPage from './components/CartPage.jsx';
import CheckoutPage from './components/CheckoutPage.jsx'
import ServicesSection from './components/ServicesSection.jsx';
import AboutAndServices from './components/AboutAndServices.jsx';
import GlobalBrandSection  from './components/GlobalBrandSection.jsx';
import WorkflowSection from './components/WorkflowSection.jsx';
import VisionMissionSection from './components/VisionMissionSection.jsx';
import LoginPage from './components/LoginPage.jsx';
import Dammi from './components/Dammi.jsx';
import ChipCards from './components/ChipCards.jsx';
import Section from './components/Section.jsx';
import SemiconductorSections from './components/SemiconductorSections.jsx';
import ContactSection from './components/ContactSection.jsx';


function App() {
  return (
    <div className="App">
    <Headers />
    {/* <Footer/> */}
    {/* <BusinessIntro/> */}
    <About/>
    <ServicesSection/>
    <VisionMissionSection/>
    <GlobalBrandSection/>
    <WorkflowSection/>
    <TeamSection/>
    <Testimonials/>
    <BlogSection/>
    {/* <MarqueeText/> */}
    <OurProcess/>
    <ProjectsSection/>
    {/* <GoalsSection/> */}
    {/* <ContactUs/> */}
    {/* <MapSection/> */}
     {/* <BusinessIntro/> */}
     <ContactSection/>
     <ContactUs/>
     <MapSection/>
      <MarqueeText/>
      <BusinessIntro/>
      
    {/* <ServicesSection/>
    <AboutAndServices/>
    <GlobalBrandSection/> */}
    {/* <WorkflowSection/>
    <VisionMissionSection/> */}
    <Footer/>
    {/* <LoginPage/>
    <CartPage/>
    <CheckoutPage/> */}
    
    {/* <Dammi/>
    <ChipCards/>
    <SemiconductorSections/>
    <ContactUs/> */}
   {/* <Section/> */}
      
       </div>
  );
}

export default App;
